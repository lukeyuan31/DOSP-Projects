# Tapestry

### Key Functions
#### Find Root Node
```python
# * Each slot in routing table might contain multiple items(up to K, K=3 in the paper),
# maybe need to muldify this function to choose the closest neighbor from certain slot
# to be the next hop.
# * If two consecutive next_hop() return the same nid, the nid should be a root node.
# Or next_hop() returns the nid of itself, the current node should be a root node.

def next_hop(level, guid): 
	if level > max_level(rt): 
		return self
	else:
		d = guid[level-1] # the level-th digit of guid
		e = rt[level, index_of(d)] # e is the slot of rt based on level and 
		while e == nil:
			d = (d + 1) % b # b is the number of symbols in ID space
			e = rt[level, d]
		if e == self: # current node might be the root node of guid, check the next digit
			return next_hop(level+1, guid)
		else:
			return e

```

#### Publish and Query

```python
# * Publish guid to nid, if current node isn't guid's root node, forward it to the next hop
# * This function should be called periodically according to the paper

def publish_object(guid, level, sid, nid): # sid is the server id, nid is the current node id
	next_node = next_hop(level, guid)
	if next_node == self:
		store (guid, sid) in self's storage
	else:
		store (guid, sid) in self's cache
		publish_object(guid, level+1, sid, next_node)
		
# When calling this function, level should be set to 1
```

``` python
def query_object(guid, level, nid):
	if guid in self's cache:
		return (guid, sid) from cache
		
	next_node = next_hop(level, guid)
	if next_node == self:
		return (guid, sid) from storage
	else:
		query_object(guid, level+1, next_node)
		
# When calling this function, level should be set to 1
```


#### Insert Node

```python
# Consider using a priority queue for each (prefix, j) slot
# a is the length of common prefix, func is a callback function, nid is id of current node
def acknowledged_multicast(a, new_nid, func, nid):
	if nid[0:a-1] != new_nid[0:a-1]: # prefix not match
		raise error
	other_node_with_same_prefix = False
	child_acknowlegements = []
	if a+1 <= max_level(rt): 
		for j = 0 to b-1:
			if rt[a+1, j] != nil:
				for nb in rt[a+1, j]:
					if nb is self: continue
					other_node_with_same_prefix = True
					ack = acknowledged_multicast(a+1, new_nid, func, nb)
					add ack to child_acknowlegements
	if not other_node_with_same_prefix: # only self is in the current level, potentially need to transfer some objects rooted at current node to the new node. It also suggests reaching a leave of the tree of nodeIDs
		func(a+1, new_nid, nid)
	wait until received all child_acknowlegements
	send acknowlegement

def add2table_and_transfer_root(level, new_nid, nid):
	if level > max_level(rt):
		extend the level of rt to level
		rt[level, index_of(nid[level-1])] = nid # add self to the new extended level
	rt[level, index_of(new_nid[level-1])] = new_nid # add new node to routing table
	add nid to be the backpointer of new_nid
		
	if (new_id >= nid): # don't need to transfer in this case
		return
	else:
		send all the references in storage to new_nid
		delete all the references in storage
	
```

```python
def acquire_routing_table(new_nid, root_nid, nid):
	a = get_greatest_common_prefix_length(new_nid, root_nid) # to be the max level of the new node
	return_list = receive from acknowledged_multicast(a, new_nid, send_self_nid(new_id), nid)
	build_table_from_list(return_list, a)
	for i = a to 1:
		return_list = get_next_list(return_list, i)
		build_table_from_list(return_list, i)
		
def send_self_nid(new_nid, nid):
	send nid to new_nid
	
def get_backward_pointers(nid, level, sender_nid):
	j = index_of(nid[level-1])
	send bps[level, j] to sender_nid
	
def build_table_from_list(return_list, i):
	trim_list = get_closest_k(return_list)
	for nb_nid in trim_list:
		add nb_nid to the corresponding slot of routing table at level i
		add self to be the backward pointer of nb_nid 
	
def get_next_list(nb_list, level):
	next_list = []
	for nb in nb_list:
		temp = get_backward_pointers(nb, level, nid)
		add temp to next_list
	return next_list
```

```python
# nid is the id of gateway node where the new node choose to enter the network
def insert_node(new_nid, nid):
	root_nid = get_root_node(new_nid)
	a = get_greatest_common_prefix_length(nid, root_nid)
	initial the routing table of new node to be the same as root node's
	acknowledged_multicast(a, new_nid, add2table_and_transfer_root, nid)
	acquire_routing_table(new_nid, root_nid, nid)
	
def get_root_node(new_nid):
	level = 1
	next_nid = -1
	do:
		last_nid = next_nid
		next_nid = next_hop(level, new_nid)
	while(last_nid != next_nid)
	return next_nid
	
```
#### State of a Node

``` python
module Node:
	rt # routing table (#item in each slot (fixed) x #symbols x #levels)
	bps # backward pointers (#item in each slot (not fixed) x #symbols x #levels)
	nid # node id
	pid # process id
	max_level # max level of current routing table
	storage
	cache
		
```

### Remarks (I might neglect in the pseudo code):
* Each time add a node to routing table, also need to send itself's nid to the added node as a backpointer
* Main process can maintain a list of active nodes, and each time a new node comes, let a random active node to be its gateway node (entrance point)
* Store corresponding pid with nid to be able to send messages
* Level of routing tables starts at 1 (not 0) in accord with the paper
* Need a function to generate random IDs (using SHA-1 algorithm)
* Need a metric to measure the distance of two IDs (required by get\_closest\_k). The distance should be 0 if the two IDs are identical.
```

Documentation can be generated with [ExDoc](https://github.com/elixir-lang/ex_doc)
and published on [HexDocs](https://hexdocs.pm). Once published, the docs can
be found at [https://hexdocs.pm/proj3](https://hexdocs.pm/proj3).

