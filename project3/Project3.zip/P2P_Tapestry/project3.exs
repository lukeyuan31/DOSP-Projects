
numNodes = String.to_integer(Enum.at(System.argv,0))
numRequests = String.to_integer(Enum.at(System.argv,1))
Tapestry.main(numNodes, numRequests)

