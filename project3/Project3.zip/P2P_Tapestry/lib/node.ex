defmodule Node do
    use GenServer
    @k 10
    @verbose false

    def init([]) do
        {:ok, [rt: %{}, bp: %{}, nid: '', max_level: 0, storage: %{}, cache: %{}, return_list: [], pos: {}, root_pid: nil]}   # routing table, backpointers, nid, max_level of current routing table, storage, cache. 
    end

    def start_node() do
        {:ok, pid}=GenServer.start_link(__MODULE__,  []) 
        pid
    end

    def initialNode(pid, max_N) do
        state = getState(pid)
        nid = Util.getHash(Kernel.inspect(pid))
        updateState(pid, :nid, nid)
        updateState(pid, :pos, {:rand.uniform(), :rand.uniform()})
        initialRT(pid, max_N)
        initialBP(pid)
    end

    def getState(pid) do
        GenServer.call(pid, {:getState}, :infinity)
    end

    def handle_call({:getState}, _from, state) do
        {:reply, state, state}
    end

    def updateState(pid, key, new_val) do
        GenServer.call(pid, {:updateState, key, new_val}, :infinity)
    end

    def handle_call({:updateState, key, new_val}, _from, state) do
        new_state = Keyword.update!(state, key, fn _ -> new_val end)
        {:reply,:ok,new_state}
    end

    def initialRT(pid, max_N) do
        GenServer.call(pid, {:initialRT, max_N}, :infinity)
    end

    def handle_call({:initialRT, max_N}, _from, state) do
        max_level = ceil(:math.log(max_N) / :math.log(16))
        rt = for l <- 1..max_level, into: %{} do 
            row = for b <- 0..15, into: %{} do
                char = Integer.to_string(b, 16)
                if String.at(state[:nid], l-1) == char, do: {char, [{state[:nid], self(), elem(state[:pos], 0), elem(state[:pos], 1)}]}, else: {char, []}
            end
            {l, row}
        end
        
        state = Keyword.update!(state, :rt, fn _ -> rt end)
        state = Keyword.update!(state, :max_level, fn _ -> max_level end)
        {:reply, :ok, state}
    end

    def handle_call({:copyRT, rootRT, level}, _from, state) do
        max_level = state[:max_level]
        rt = for l <- 1..max_level, into: %{} do 
            row = for b <- 0..15, into: %{} do
                char = Integer.to_string(b, 16)
                if l <= level do
                    {char, Enum.uniq(state[:rt][l][char] ++ rootRT[l][char])}
                else
                    {char, state[:rt][l][char]}
                end
            end
            {l, row}
        end
        state = Keyword.update!(state, :rt, fn _ -> rt end)
        {:reply, :ok, state}
    end

    def initialBP(pid) do
        GenServer.call(pid, {:initialBP}, :infinity)
    end

    def handle_call({:initialBP}, _from, state) do
        max_level = state[:max_level]
        bp = for l <- 1..max_level, into: %{} do 
            row = for b <- 0..15, into: %{} do
                char = Integer.to_string(b, 16)
                {char, []}
            end
            {l, row}
        end
        
        state = Keyword.update!(state, :bp, fn _ -> bp end)
        {:reply, :ok, state}
    end

    defp _loop(e, d, rt_level) do
        if length(e) == 0 do
            d_idx = String.to_integer(d, 16)
            d = Integer.to_string(rem(d_idx + 1, 16), 16)
            e = rt_level[d]
            _loop(e, d, rt_level)
        else
            e
        end
    end
    
    def nextHop(pid, level, guid) do 
        if @verbose, do: IO.inspect(["nextHop", pid, level])
        state = getState(pid)
        if level > state[:max_level] do
            pid
        else
            d = String.at(guid, level - 1)
            es = state[:rt][level][d]
            es = _loop(es, d, state[:rt][level])
            e = Enum.at(es, 0)
            if elem(e, 0) == state[:nid] do
                nextHop(pid, level+1, guid)
            else
                elem(e, 1)
            end 
        end 
    end

        
    def publishObject(pid, guid, sid, level) do
        next_pid = nextHop(pid, level, guid)
        state = getState(pid)
        if next_pid == pid do
            storage = Map.put(state[:storage], guid, sid)
            updateState(pid, :storage, storage)
        else
            cache = Map.put(state[:storage], guid, sid) 
            updateState(pid, :cache, cache)
            publishObject(next_pid, guid, sid, level)
        end
    end

    def queryObject(pid, guid, level) do
        state = getState(pid)
        if Map.has_key?(state[:cache], guid) do
            {state[:cache][guid], level}
        else
            next_node = nextHop(pid, level, guid)
            if next_node == pid do
                {state[:storage][guid], level}
            else
                queryObject(next_node, guid, level+1)
            end
        end
    end

    def acknowledgedMulticast(pid, new_pid, a, level, func) do # a is the length of common prefix
        if @verbose, do: IO.inspect(["acknowledgedMulticast", pid, new_pid, a])

        state = getState(pid)
        max_level = state[:max_level]
        if level >= max_level do
            func.(pid, a+1, new_pid)
        else
            tasks = for j <- 0..15 do
                b = Integer.to_string(j, 16)
                if length(state[:rt][a+1][b]) != 0 do 
                    for nb <- state[:rt][a+1][b] do
                        nb_pid = elem(nb, 1)
                        if nb_pid != pid do
                            task = Task.async(fn -> 
                                acknowledgedMulticast(nb_pid, new_pid, a, level+1, func)
                            end)
                            task
                        end
                    end
                end
            end
            
            tasks = List.flatten(tasks)
            tasks = Enum.filter(tasks, fn x -> not is_nil(x) end)
            for task <- tasks, do: Task.await(task, :infinity)
            if length(tasks) == 0 do
                func.(pid, a+1, new_pid) 
            end
        end
        
    end


    def add2TableAndTransferRoot(pid, level, new_pid) do 
        if @verbose, do: IO.inspect(["add2TableAndTransferRoot", pid, level, new_pid])
        state = getState(pid)
        rt = state[:rt]
        new_nid = getState(new_pid)[:nid]
        {new_x, new_y} = getState(new_pid)[:pos]
        if not Enum.member?(rt[level][String.at(new_nid, level-1)], {new_nid, new_pid}) do
            add2TableSlot(pid, level, String.at(new_nid, level-1), {new_nid, new_pid, new_x, new_y}) # CHANGED
            add2BackPointer(new_pid, level, state[:nid], pid)
        else
            storage = state[:storage]
            updateState(new_pid, :storage, Map.merge(getState(new_pid)[:storage], storage))
            updateState(pid, :storage, %{})
        end
    end

    def add2BackPointer(pid, level, new_nid, new_pid) do 
        if @verbose, do: IO.inspect(["add2BackPointer", pid, level, new_pid])
        state = getState(pid)
        bp = state[:bp]
        bp_level = Map.update!(bp[level], String.at(new_nid, level-1), fn list -> list ++ [{new_nid, new_pid}] end)
        bp = Map.update!(bp, level, fn _ -> bp_level end)
        updateState(pid, :bp, bp)
    end
    
    def acquireRoutingTable(pid, root_pid) do 
        if @verbose, do: IO.inspect(["acquireRoutingTable", pid, root_pid])
        new_node_nid = getState(pid)[:nid]
        root_nid = getState(root_pid)[:nid]
        a = Util.findPrefix(new_node_nid, root_nid)
        a = min(a, getState(pid)[:max_level]-1)
        acknowledgedMulticast(root_pid, pid, a, a+1, &sendSelfNidPid/3)
        return_list = getState(pid)[:return_list]
        if @verbose, do: IO.inspect(["return_list", new_node_nid, a + 1, return_list])
        buildTableFromList(pid, return_list, a+1, @k)
        if @verbose, do: IO.inspect(["after return list", getState(pid)[:rt]])
        if a > 1 do
            for level <- a..1 do
                return_list = getNextList(pid, return_list, level)
                buildTableFromList(pid, return_list, level, @k)
            end
        end
    end

    def sendSelfNidPid(pid, level, new_pid) do
        if @verbose, do: IO.inspect(["sendSelfNidPid", pid, level, new_pid])
        state = getState(pid)
        GenServer.call(new_pid, {:nid_pid, state[:nid], pid, elem(state[:pos], 0), elem(state[:pos], 1)}, :infinity)
    end

    def handle_call({:nid_pid, nid, pid, x, y}, _from, state) do
        return_list = state[:return_list] ++ [{nid, pid, x, y}]
        if @verbose, do: IO.inspect(["in handle call", self(), pid])
        state = Keyword.update!(state, :return_list, fn _ -> return_list end)
        {:reply, :ok, state}
    end

    def add2TableSlot(pid, level, char, {nb_nid, nb_pid, nb_x, nb_y}) do
        state = getState(pid)
        rt = state[:rt]
        ori_slot_val = rt[level][String.at(nb_nid, level-1)]
        if not Enum.member?(ori_slot_val, {nb_nid, nb_pid}) do
            new_slot_val = if length(ori_slot_val) == 0 do 
                [{nb_nid, nb_pid, nb_x, nb_y}]
            else
                # self_tuple = {state[:nid], pid, elem(state[:pos], 0), elem(state[:pos], 1)}
                # KNN.sort({state[:nid], pid, 0, 0}, ori_slot_val ++ [{nb_nid, nb_pid, nb_x, nb_y}]) |> Enum.uniq
                ori_slot_val ++ [{nb_nid, nb_pid, nb_x, nb_y}] |> Enum.uniq
            end  
            rt_level = Map.update!(rt[level], String.at(nb_nid, level-1), fn _ -> new_slot_val end) 
            rt = Map.update!(rt, level, fn _ -> rt_level end)
            updateState(pid, :rt, rt)
        end
    end


    def buildTableFromList(pid, return_list, level, k) do
        if @verbose, do: IO.inspect(["buildTableFromList", pid, level, length(return_list)])
        state = getState(pid)
        return_list = Enum.uniq(return_list)
        trim_list = KNN.compute({state[:nid], state[:pid], elem(state[:pos], 0), elem(state[:pos], 1)}, return_list, k)
        if @verbose, do: IO.inspect(["trim_list", trim_list])
        for {nb_nid, nb_pid, nb_x, nb_y} <- trim_list do
            rt = getState(pid)[:rt]
            if not Enum.member?(rt[level][String.at(nb_nid, level-1)], {nb_nid, nb_pid}) do
                add2TableSlot(pid, level, String.at(nb_nid, level-1), {nb_nid, nb_pid, nb_x, nb_y}) 
                add2BackPointer(nb_pid, level, state[:nid], pid)
            end
        end
    end


    def getNextList(pid, nb_list, level) do
        next_list = for nb <- nb_list do
            getForwardBackwordPointers(elem(nb, 1), level)
        end
        next_list = List.flatten(next_list)
        next_list = for {nid, pid} <- next_list do
            pos = getState(pid)[:pos]
            {nid, pid, elem(pos, 0), elem(pos, 1)}
        end
    end    
    
    def getForwardBackwordPointers(pid, level) do
        if @verbose, do: IO.inspect(["getForwardBackwordPointers", pid, level])
        state = getState(pid)
        rt_row = state[:rt][level]
        bp_row = state[:bp][level+1]
        rt_and_bp = Map.merge(rt_row, bp_row, fn _k, list1, list2 -> list1 ++ list2 end)
        Map.values(rt_and_bp)
    end


    def insertNode(pid, new_pid) do
        if @verbose, do: IO.inspect(["insertNode", pid, new_pid])
        new_nid = getState(new_pid)[:nid]
        max_level = getState(pid)[:max_level]
        root_pid = findRootNode(pid, new_nid, 1)
        updateState(new_pid, :root_pid, root_pid)
        root_nid = getState(root_pid)[:nid]
        a = Util.findPrefix(new_nid, root_nid)
        a = min(a, max_level-1)
        GenServer.call(new_pid, {:copyRT, getState(root_pid)[:rt], a+1}, :infinity) # TODO
        acknowledgedMulticast(root_pid, new_pid, a, a+1, &add2TableAndTransferRoot/3)
        acquireRoutingTable(new_pid, root_pid)
    end

    def findRootNode(pid, new_nid, level) do
        if @verbose, do: IO.inspect(["findRootNode", getState(pid)[:nid], new_nid, level])
        next_node = nextHop(pid, level, new_nid)
        if next_node == pid do
            next_node
        else
            findRootNode(next_node, new_nid, level+1)
        end
    end

end