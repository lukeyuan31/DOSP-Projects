defmodule Util do
    #Use sha-1 algorithm to generate the nid
    def getHash(key) do
        :crypto.hash(:sha, key) |> Base.encode16
    end

    def findPrefix(string1, string2) do
        index = Enum.find_index(0..String.length(string1) , fn(i)->
            String.at(string1,i)!=String.at(string2,i)
        end)
        if index, do: String.length(String.slice(string1, 0, index)), else: String.length(string1)
    end
    
end
