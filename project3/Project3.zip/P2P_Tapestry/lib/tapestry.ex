defmodule Tapestry do
  def checkState(pid) do
    state = Node.getState(pid)
    max_level = state[:max_level]
    IO.inspect(pid)
    IO.inspect(state[:nid])
    if not is_nil(state[:root_pid]) do
      root_nid = Node.getState(state[:root_pid])[:nid]
      IO.inspect(["root node", root_nid])
    end
    
    for level <- 1..max_level do
      for j <- 0..15 do
        if (length(state[:rt][level][Integer.to_string(j, 16)]) != 0) do
          IO.inspect([level, Integer.to_string(j, 16), "=>", 
          state[:rt][level][Integer.to_string(j, 16)]
          ])
        end
      end
    end
    
  end

  def printNids(node_list, n ) do
    #print the first n digits all the nid, used for debugging
    Enum.map(0..length(node_list)-1, fn i ->
      pid = Enum.at(node_list, i)
      nid = Node.getState(pid)[:nid]
      IO.inspect([i, String.slice(nid, 0..n-1)])
    end)
  end

  def main(numNodes, numRequests) do
    node_list = Enum.map(1..numNodes, fn _ -> Node.start_node() end)
    # IO.inspect(node_list)
    Node.initialNode(Enum.at(node_list, 0), numNodes)
    Enum.map(1..numNodes-1, fn i ->
      node_pid = Enum.at(node_list, i)
      Node.initialNode(node_pid, numNodes)
      gateway_idx = :rand.uniform(i) - 1
      gateway_pid = Enum.at(node_list, gateway_idx)
      Node.insertNode(gateway_pid, node_pid)
    end)

    # Enum.map(0..numNodes-1, fn i ->
    #   node_pid = Enum.at(node_list, i)
    #   IO.inspect("=================================#{i}========================================")
    #   checkState(node_pid)
    # end)
    # printNids(node_list, 3)

    max_hop = 0
    rets = for i <- 1..numRequests do    
      guid = Util.getHash(Kernel.inspect(System.monotonic_time(:millisecond)))
      :timer.sleep(1)
      sid = Util.getHash(Kernel.inspect(System.monotonic_time(:millisecond)))
      enter_idx = :rand.uniform(numNodes) - 1
      enter_pid = Enum.at(node_list, enter_idx)
      Node.publishObject(enter_pid, guid, sid, 1)
      gateway_idx = :rand.uniform(numNodes) - 1
      gateway_pid = Enum.at(node_list, gateway_idx)
      ret = Node.queryObject(gateway_pid, guid, 1)
      ret
    end

    {guids, num_hops} = Enum.unzip(rets)
    # IO.inspect(length(Enum.filter(guids, fn x -> not is_nil(x) end)) / numRequests)
    IO.puts(Enum.max(num_hops))
  end
end
